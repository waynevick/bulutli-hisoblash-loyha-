from flask import Flask, render_template, request
from collections import Counter
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    stats = None
    if request.method == 'POST':
        file = request.files['file']
        if file and file.filename.endswith('.txt'):
            filepath = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filepath)
            with open(filepath, 'r', encoding='utf-8') as f:
                text = f.read()
            words = text.split()
            word_count = len(words)
            top_words = Counter(words).most_common(5)
            stats = {
                'word_count': word_count,
                'top_words': top_words
            }
    return render_template('index.html', stats=stats)

if __name__ == '__main__':
    app.run(debug=True)
